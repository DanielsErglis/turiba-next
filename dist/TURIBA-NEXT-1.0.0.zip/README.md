# TURIBA NEXT 1.0.0

Independent student project. Acceptance: owner-confirmed iPhone acceptance on 2026-10-30; detailed device metadata not supplied.

Import TURIBA NEXT.js into Scriptable. No Node.js or extra modules are needed on the phone. Read docs/INSTALL_RU.md for setup and updates, docs/PRIVACY.md for privacy, docs/TROUBLESHOOTING.md for help, and docs/IPHONE_CHECKLIST.md for required native checks.

Development source and history: https://github.com/DanielsErglis/turiba-next (private). No public distribution is authorized.
