# TURIBA NEXT 1.0.0-rc.4

Independent student project. Physical-iPhone acceptance pending.

Import TURIBA NEXT.js into Scriptable. No Node.js or extra modules are needed on the phone. Read docs/INSTALL_RU.md for setup and updates, docs/PRIVACY.md for privacy, docs/TROUBLESHOOTING.md for help, and docs/IPHONE_CHECKLIST.md for required native checks.

Development source and history: https://github.com/DanielsErglis/turiba-next (private). No public distribution is authorized.
